"""
Thuat toan tim duong cho robot trong kho hang:
- A* (f(n) = g(n) + h(n))
- Greedy Best First Search (chi dung h(n))
h(n) la khoang cach Manhattan.

Gia tri o luoi:
  0 = duong di duoc (free)
  1 = ke hang / vat can co dinh
  2 = robot khac / vat can tam thoi
"""
import heapq
import time


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def neighbors(pos, rows, cols):
    r, c = pos
    # Uu tien 4 huong: len, xuong, trai, phai
    for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        nr, nc = r + dr, c + dc
        if 0 <= nr < rows and 0 <= nc < cols:
            yield (nr, nc)


def is_walkable(grid, pos):
    r, c = pos
    return grid[r][c] == 0


def reconstruct_path(came_from, current):
    path = [current]
    while current in came_from:
        current = came_from[current]
        path.append(current)
    path.reverse()
    return path


def astar(grid, start, goal):
    """A*: f(n) = g(n) + h(n). Tra ve (path, so_nut_mo_rong, thoi_gian_ms)."""
    rows, cols = len(grid), len(grid[0])
    if start == goal:
        return [start], 0, 0.0

    counter = 0
    open_heap = [(manhattan(start, goal), counter, start)]
    came_from = {}
    g_score = {start: 0}
    closed = set()
    expanded = 0
    t0 = time.perf_counter()

    while open_heap:
        _, _, current = heapq.heappop(open_heap)
        if current in closed:
            continue
        closed.add(current)
        expanded += 1

        if current == goal:
            elapsed = (time.perf_counter() - t0) * 1000
            return reconstruct_path(came_from, current), expanded, elapsed

        for nb in neighbors(current, rows, cols):
            if not is_walkable(grid, nb):
                continue
            tentative_g = g_score[current] + 1
            if nb not in g_score or tentative_g < g_score[nb]:
                g_score[nb] = tentative_g
                came_from[nb] = current
                f = tentative_g + manhattan(nb, goal)
                counter += 1
                heapq.heappush(open_heap, (f, counter, nb))

    elapsed = (time.perf_counter() - t0) * 1000
    return None, expanded, elapsed


def greedy_best_first(grid, start, goal):
    """Greedy Best First Search: chi dung h(n) de sap xep hang doi uu tien."""
    rows, cols = len(grid), len(grid[0])
    if start == goal:
        return [start], 0, 0.0

    counter = 0
    open_heap = [(manhattan(start, goal), counter, start)]
    came_from = {}
    visited = {start}
    closed = set()
    expanded = 0
    t0 = time.perf_counter()

    while open_heap:
        _, _, current = heapq.heappop(open_heap)
        if current in closed:
            continue
        closed.add(current)
        expanded += 1

        if current == goal:
            elapsed = (time.perf_counter() - t0) * 1000
            return reconstruct_path(came_from, current), expanded, elapsed

        for nb in neighbors(current, rows, cols):
            if not is_walkable(grid, nb) or nb in visited:
                continue
            visited.add(nb)
            came_from[nb] = current
            counter += 1
            heapq.heappush(open_heap, (manhattan(nb, goal), counter, nb))

    elapsed = (time.perf_counter() - t0) * 1000
    return None, expanded, elapsed


ALGORITHMS = {
    "astar": astar,
    "greedy": greedy_best_first,
}
