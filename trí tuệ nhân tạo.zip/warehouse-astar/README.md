# Robot tự động lấy hàng trong kho — A* Navigator

Ứng dụng web mô phỏng robot tự động tìm đường trong kho hàng dạng lưới bằng
thuật toán **A\*** và **Greedy Best-First Search**, có robot khác di chuyển
ngẫu nhiên làm vật cản tạm thời, tự động tính lại đường đi định kỳ (mỗi 5
bước) hoặc ngay khi phát hiện vật cản mới chặn đường.

## Cài đặt & chạy

```bash
cd warehouse-astar
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Mở trình duyệt tại: **http://localhost:5000**

## Tính năng đáp ứng đề bài

- **Mô hình lưới ô vuông**, kích thước tối thiểu 30×30 (có thể chỉnh tới 60×60).
  - `0` = ô trống, `1` = kệ hàng cố định, `2` = robot khác (vật cản tạm thời).
- **A\*** với `f(n) = g(n) + h(n)`, `h(n)` là khoảng cách Manhattan.
- **Greedy Best-First Search** chỉ dùng `h(n)`.
- Di chuyển 4 hướng (lên/xuống/trái/phải), chi phí mỗi bước = 1.
- **3–5 robot khác** di chuyển ngẫu nhiên mỗi bước mô phỏng.
- **Cập nhật đường đi động**: sau mỗi 5 bước hệ thống tự kiểm tra và tính lại
  đường nếu cần; ngoài ra nếu một robot khác bất ngờ chặn ngay ô kế tiếp trên
  đường đi, hệ thống tính lại đường ngay lập tức.
- Tab **"So sánh thuật toán"**: chạy A* và Greedy trên cùng một bản đồ, hiển
  thị song song 2 đường đi cùng bảng so sánh độ dài đường đi, số nút mở rộng
  và thời gian tính.
- Giao diện web: bảng điều khiển, canvas mô phỏng theo thời gian thực, thẻ
  trạng thái, bảng số liệu và nhật ký hệ thống dạng console.

## Cấu trúc thư mục

```
warehouse-astar/
├── app.py            # Flask backend + logic mô phỏng, sinh bản đồ, robot động
├── algorithms.py      # Cài đặt A* và Greedy Best-First Search
├── templates/
│   └── index.html     # Giao diện chính
├── static/
│   ├── style.css       # Giao diện "phòng điều khiển kho hàng"
│   └── app.js           # Vẽ canvas, gọi API, vòng lặp mô phỏng
└── requirements.txt
```
