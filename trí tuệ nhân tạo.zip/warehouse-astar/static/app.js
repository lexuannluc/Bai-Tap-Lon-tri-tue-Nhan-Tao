(() => {
  const COLORS = {
    free: '#0D1219',
    gridLine: '#1B2530',
    shelfA: '#3a4a5c',
    shelfB: '#2a3644',
    dyn: '#F2A93B',
    robot: '#3FD0F2',
    path: '#3FD0F2',
    start: '#4CD97B',
    goal: '#F2534A',
  };

  let simId = null;
  let state = null;
  let playing = false;
  let timer = null;

  const $ = (id) => document.getElementById(id);
  const canvasSim = $('canvasSim');
  const ctxSim = canvasSim.getContext('2d');

  // ---------------- helpers ----------------
  function cellSizeFor(rows, cols) {
    const maxDim = 640;
    return Math.max(8, Math.floor(maxDim / Math.max(rows, cols)));
  }

  function drawGrid(ctx, canvas, rows, cols, cell, staticGrid, dynamic, start, goal, robotPos, path) {
    canvas.width = cols * cell;
    canvas.height = rows * cell;
    ctx.fillStyle = COLORS.free;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // static obstacles (shelves)
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (staticGrid[r][c] === 1) {
          ctx.fillStyle = ((r + c) % 2 === 0) ? COLORS.shelfA : COLORS.shelfB;
          ctx.fillRect(c * cell, r * cell, cell, cell);
        }
      }
    }

    // grid lines
    ctx.strokeStyle = COLORS.gridLine;
    ctx.lineWidth = 1;
    for (let r = 0; r <= rows; r++) {
      ctx.beginPath(); ctx.moveTo(0, r * cell + 0.5); ctx.lineTo(cols * cell, r * cell + 0.5); ctx.stroke();
    }
    for (let c = 0; c <= cols; c++) {
      ctx.beginPath(); ctx.moveTo(c * cell + 0.5, 0); ctx.lineTo(c * cell + 0.5, rows * cell); ctx.stroke();
    }

    // path (dashed)
    if (path && path.length > 1) {
      ctx.save();
      ctx.strokeStyle = COLORS.path;
      ctx.lineWidth = Math.max(2, cell * 0.18);
      ctx.setLineDash([cell * 0.35, cell * 0.25]);
      ctx.globalAlpha = 0.85;
      ctx.beginPath();
      path.forEach(([r, c], i) => {
        const x = c * cell + cell / 2, y = r * cell + cell / 2;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.stroke();
      ctx.restore();
    }

    // start / goal markers
    drawDiamond(ctx, start, cell, COLORS.start);
    drawDiamond(ctx, goal, cell, COLORS.goal);

    // dynamic robots
    (dynamic || []).forEach((p) => drawCircle(ctx, p, cell, COLORS.dyn, 0.32));

    // main robot
    if (robotPos) drawCircle(ctx, robotPos, cell, COLORS.robot, 0.36, true);
  }

  function drawCircle(ctx, [r, c], cell, color, ratio, glow) {
    const cx = c * cell + cell / 2, cy = r * cell + cell / 2, radius = cell * ratio;
    if (glow) {
      ctx.save();
      ctx.shadowColor = color;
      ctx.shadowBlur = cell * 1.1;
    }
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.fill();
    if (glow) ctx.restore();
  }

  function drawDiamond(ctx, [r, c], cell, color) {
    const cx = c * cell + cell / 2, cy = r * cell + cell / 2, s = cell * 0.30;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(cx, cy - s); ctx.lineTo(cx + s, cy); ctx.lineTo(cx, cy + s); ctx.lineTo(cx - s, cy);
    ctx.closePath(); ctx.fill();
  }

  function log(line) {
    const el = document.createElement('div');
    el.textContent = line;
    $('logBody').appendChild(el);
    $('logBody').scrollTop = $('logBody').scrollHeight;
  }

  function renderSim() {
    if (!state) return;
    const cell = cellSizeFor(state.rows, state.cols);
    drawGrid(ctxSim, canvasSim, state.rows, state.cols, cell, state.static_grid,
      state.dynamic_positions, state.start, state.goal, state.robot_pos, state.path);

    $('statAlgo').textContent = state.algorithm === 'astar' ? 'A*' : 'Greedy BFS';
    $('statLen').textContent = state.path_length;
    $('statExpanded').textContent = state.nodes_expanded;
    $('statTime').textContent = state.plan_time_ms + ' ms';
    $('statMoves').textContent = state.moves;
    $('statReplans').textContent = state.replans;

    const chip = $('statusChip');
    chip.className = 'status-chip ' + state.status;
    chip.textContent = state.status === 'moving' ? 'ĐANG DI CHUYỂN'
      : state.status === 'done' ? 'ĐÃ ĐẾN ĐÍCH'
      : 'KHÔNG TÌM ĐƯỢC ĐƯỜNG';

    $('logBody').innerHTML = '';
    (state.log || []).forEach(log);

    if (state.status !== 'moving') stopPlaying();
  }

  // ---------------- API calls ----------------
  async function newSimulation() {
    stopPlaying();
    const body = {
      rows: parseInt($('rows').value, 10),
      cols: parseInt($('cols').value, 10),
      density: parseInt($('density').value, 10) / 100,
      num_robots: parseInt($('numRobots').value, 10),
      algorithm: $('algorithm').value,
    };
    const res = await fetch('/api/new_simulation', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    state = await res.json();
    simId = state.sim_id;
    renderSim();
  }

  async function doStep() {
    if (!simId) return;
    const res = await fetch('/api/step', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sim_id: simId }),
    });
    state = await res.json();
    renderSim();
  }

  async function doCompare() {
    if (!simId) return;
    switchTab('compare');
    const res = await fetch('/api/compare', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sim_id: simId }),
    });
    const data = await res.json();
    renderCompare(data);
  }

  function renderCompare(data) {
    const cell = cellSizeFor(data.rows, data.cols);
    const cA = $('canvasAstar'), cG = $('canvasGreedy');
    drawGrid(cA.getContext('2d'), cA, data.rows, data.cols, cell, data.static_grid,
      data.dynamic_positions, data.start, data.goal, null, data.results.astar.path);
    drawGrid(cG.getContext('2d'), cG, data.rows, data.cols, cell, data.static_grid,
      data.dynamic_positions, data.start, data.goal, null, data.results.greedy.path);

    const rows = [
      ['A*', data.results.astar],
      ['Greedy Best-First', data.results.greedy],
    ];
    $('compareTableBody').innerHTML = rows.map(([name, r]) => `
      <tr>
        <td>${name}</td>
        <td>${r.found ? '<span style="color:#4CD97B">Có</span>' : '<span style="color:#F2534A">Không</span>'}</td>
        <td>${r.found ? r.path_length + ' bước' : '—'}</td>
        <td>${r.nodes_expanded}</td>
        <td>${r.time_ms}</td>
      </tr>
    `).join('');
  }

  // ---------------- autoplay ----------------
  function startPlaying() {
    if (playing || !state || state.status !== 'moving') return;
    playing = true;
    $('btnPlay').disabled = true;
    $('btnPause').disabled = false;
    const speed = parseInt($('speed').value, 10);
    timer = setInterval(doStep, speed);
  }
  function stopPlaying() {
    playing = false;
    $('btnPlay').disabled = false;
    $('btnPause').disabled = true;
    if (timer) clearInterval(timer);
    timer = null;
  }

  // ---------------- tabs ----------------
  function switchTab(name) {
    document.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
    $('view-sim').classList.toggle('hidden', name !== 'sim');
    $('view-compare').classList.toggle('hidden', name !== 'compare');
  }

  // ---------------- wire up ----------------
  document.querySelectorAll('.tab-btn').forEach((b) => b.addEventListener('click', () => switchTab(b.dataset.tab)));

  $('density').addEventListener('input', (e) => { $('densityVal').textContent = e.target.value + '%'; });
  $('numRobots').addEventListener('input', (e) => { $('numRobotsVal').textContent = e.target.value; });

  $('btnNewMap').addEventListener('click', newSimulation);
  $('btnStep').addEventListener('click', doStep);
  $('btnPlay').addEventListener('click', startPlaying);
  $('btnPause').addEventListener('click', stopPlaying);
  $('btnCompareNow').addEventListener('click', doCompare);
  $('speed').addEventListener('change', () => { if (playing) { stopPlaying(); startPlaying(); } });

  // boot
  newSimulation();
})();
