import random
import uuid

from flask import Flask, jsonify, render_template, request

from algorithms import ALGORITHMS, manhattan

app = Flask(__name__)

SIMS = {}  # sim_id -> state dict

REPLAN_EVERY = 5  # theo yeu cau de bai: cu moi 5 buoc thi kiem tra lai


# --------------------------------------------------------------------------
# Sinh ban do
# --------------------------------------------------------------------------
def free_cells(static_grid):
    rows, cols = len(static_grid), len(static_grid[0])
    return [(r, c) for r in range(rows) for c in range(cols) if static_grid[r][c] == 0]


def generate_static_grid(rows, cols, density):
    grid = [[0] * cols for _ in range(rows)]
    for r in range(rows):
        for c in range(cols):
            if random.random() < density:
                grid[r][c] = 1
    return grid


def build_planning_grid(static_grid, dynamic_positions, ignore=None):
    """Ghep vat can co dinh (1) va robot khac (2) thanh 1 luoi de tim duong."""
    grid = [row[:] for row in static_grid]
    for (r, c) in dynamic_positions:
        if ignore and (r, c) == ignore:
            continue
        grid[r][c] = 2
    return grid


def random_start_goal(static_grid):
    cells = free_cells(static_grid)
    rows, cols = len(static_grid), len(static_grid[0])
    # start o vung tren-trai, goal o vung duoi-phai de co hanh trinh dai, thu vi
    top_left = [p for p in cells if p[0] < rows * 0.4 and p[1] < cols * 0.4]
    bottom_right = [p for p in cells if p[0] > rows * 0.6 and p[1] > cols * 0.6]
    start = random.choice(top_left) if top_left else random.choice(cells)
    remaining = [p for p in (bottom_right or cells) if p != start]
    goal = random.choice(remaining) if remaining else random.choice(cells)
    return start, goal


def place_dynamic_robots(static_grid, count, forbidden):
    cells = [p for p in free_cells(static_grid) if p not in forbidden]
    random.shuffle(cells)
    return cells[:count]


def make_grid_with_valid_path(rows, cols, density, num_robots, algorithm):
    for _ in range(60):
        static_grid = generate_static_grid(rows, cols, density)
        start, goal = random_start_goal(static_grid)
        if start == goal:
            continue
        dynamic_positions = place_dynamic_robots(static_grid, num_robots, {start, goal})
        planning_grid = build_planning_grid(static_grid, dynamic_positions)
        algo_fn = ALGORITHMS[algorithm]
        path, expanded, ms = algo_fn(planning_grid, start, goal)
        if path:
            return static_grid, start, goal, dynamic_positions, path, expanded, ms
    # fallback: khong vat can dong, giam mat do neu 60 lan van khong tim duoc
    static_grid = generate_static_grid(rows, cols, density * 0.3)
    start, goal = random_start_goal(static_grid)
    dynamic_positions = place_dynamic_robots(static_grid, num_robots, {start, goal})
    planning_grid = build_planning_grid(static_grid, dynamic_positions)
    algo_fn = ALGORITHMS[algorithm]
    path, expanded, ms = algo_fn(planning_grid, start, goal)
    return static_grid, start, goal, dynamic_positions, path or [start], expanded, ms


# --------------------------------------------------------------------------
# Di chuyen robot dong (vat can tam thoi)
# --------------------------------------------------------------------------
def move_dynamic_robots(static_grid, dynamic_positions, avoid):
    rows, cols = len(static_grid), len(static_grid[0])
    occupied = set(dynamic_positions) | avoid
    new_positions = []
    for pos in dynamic_positions:
        occupied.discard(pos)
        options = [pos]  # co the dung yen
        r, c = pos
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nr, nc = r + dr, c + dc
            if (
                0 <= nr < rows
                and 0 <= nc < cols
                and static_grid[nr][nc] == 0
                and (nr, nc) not in occupied
            ):
                options.append((nr, nc))
        # 70% co gang di chuyen neu co the, 30% dung yen cho tu nhien
        if len(options) > 1 and random.random() < 0.7:
            new_pos = random.choice(options[1:])
        else:
            new_pos = pos
        occupied.add(new_pos)
        new_positions.append(new_pos)
    return new_positions


def path_is_blocked(path, dynamic_positions, look_ahead=REPLAN_EVERY):
    if not path or len(path) < 2:
        return False
    dyn = set(dynamic_positions)
    for cell in path[1 : 1 + look_ahead]:
        if cell in dyn:
            return True
    return False


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/new_simulation", methods=["POST"])
def new_simulation():
    data = request.get_json(force=True)
    rows = max(30, min(60, int(data.get("rows", 30))))
    cols = max(30, min(60, int(data.get("cols", 30))))
    density = max(0.0, min(0.35, float(data.get("density", 0.18))))
    num_robots = max(3, min(5, int(data.get("num_robots", 4))))
    algorithm = data.get("algorithm", "astar")
    if algorithm not in ALGORITHMS:
        algorithm = "astar"

    static_grid, start, goal, dynamic_positions, path, expanded, ms = make_grid_with_valid_path(
        rows, cols, density, num_robots, algorithm
    )

    sim_id = str(uuid.uuid4())
    SIMS[sim_id] = {
        "rows": rows,
        "cols": cols,
        "static_grid": static_grid,
        "dynamic_positions": dynamic_positions,
        "start": start,
        "goal": goal,
        "robot_pos": start,
        "path": path,
        "algorithm": algorithm,
        "step_count": 0,
        "replans": 1,
        "moves": 0,
        "nodes_expanded": expanded,
        "path_length": len(path) - 1 if path else 0,
        "plan_time_ms": round(ms, 3),
        "status": "moving" if path and len(path) > 1 else ("done" if path else "no_path"),
        "log": [f"[Khoi tao] Tim duong bang {algorithm.upper()}: {len(path)-1} buoc, "
                f"mo rong {expanded} nut, {ms:.2f} ms."],
    }
    payload = sim_to_json(SIMS[sim_id])
    payload["sim_id"] = sim_id
    return jsonify(payload)


def sim_to_json(s):
    return {
        "rows": s["rows"],
        "cols": s["cols"],
        "static_grid": s["static_grid"],
        "dynamic_positions": s["dynamic_positions"],
        "start": s["start"],
        "goal": s["goal"],
        "robot_pos": s["robot_pos"],
        "path": s["path"],
        "algorithm": s["algorithm"],
        "step_count": s["step_count"],
        "replans": s["replans"],
        "moves": s["moves"],
        "nodes_expanded": s["nodes_expanded"],
        "path_length": s["path_length"],
        "plan_time_ms": s["plan_time_ms"],
        "status": s["status"],
        "log": s["log"][-8:],
    }


@app.route("/api/step", methods=["POST"])
def step():
    data = request.get_json(force=True)
    sim_id = data.get("sim_id")
    s = SIMS.get(sim_id)
    if not s:
        return jsonify({"error": "sim not found"}), 404

    if s["status"] != "moving":
        return jsonify(sim_to_json(s))

    # 1) Cac robot khac (vat can tam thoi) di chuyen
    s["dynamic_positions"] = move_dynamic_robots(
        s["static_grid"], s["dynamic_positions"], avoid={s["robot_pos"], s["goal"]}
    )
    s["step_count"] += 1

    need_replan = False
    reason = ""
    if s["step_count"] % REPLAN_EVERY == 0:
        need_replan = True
        reason = f"Cap nhat dinh ky sau {REPLAN_EVERY} buoc"
    if path_is_blocked(s["path"], s["dynamic_positions"]):
        need_replan = True
        reason = "Phat hien vat can moi tren duong di"

    if need_replan:
        planning_grid = build_planning_grid(
            s["static_grid"], s["dynamic_positions"], ignore=s["robot_pos"]
        )
        algo_fn = ALGORITHMS[s["algorithm"]]
        new_path, expanded, ms = algo_fn(planning_grid, s["robot_pos"], s["goal"])
        s["replans"] += 1
        s["nodes_expanded"] = expanded
        s["plan_time_ms"] = round(ms, 3)
        if new_path:
            s["path"] = new_path
            s["path_length"] = len(new_path) - 1
            s["log"].append(
                f"[Buoc {s['step_count']}] {reason} -> tinh lai bang "
                f"{s['algorithm'].upper()}: {len(new_path)-1} buoc con lai, "
                f"mo rong {expanded} nut."
            )
        else:
            s["status"] = "no_path"
            s["log"].append(
                f"[Buoc {s['step_count']}] {reason} -> KHONG tim duoc duong di moi!"
            )

    # 2) Robot chinh di chuyen 1 o theo duong hien tai (neu con duong)
    if s["status"] == "moving" and s["path"] and len(s["path"]) > 1:
        next_cell = s["path"][1]
        if next_cell in s["dynamic_positions"]:
            # bi chan dot xuat ngay truoc mat -> tinh lai ngay, khong di buoc nay
            planning_grid = build_planning_grid(
                s["static_grid"], s["dynamic_positions"], ignore=s["robot_pos"]
            )
            algo_fn = ALGORITHMS[s["algorithm"]]
            new_path, expanded, ms = algo_fn(planning_grid, s["robot_pos"], s["goal"])
            s["replans"] += 1
            s["nodes_expanded"] = expanded
            s["plan_time_ms"] = round(ms, 3)
            if new_path:
                s["path"] = new_path
                s["path_length"] = len(new_path) - 1
                s["log"].append(
                    f"[Buoc {s['step_count']}] Bi chan truc tiep -> tinh lai duong khan cap."
                )
            else:
                s["status"] = "no_path"
                s["log"].append(f"[Buoc {s['step_count']}] Bi chan va khong con duong nao!")
        else:
            s["robot_pos"] = next_cell
            s["path"] = s["path"][1:]
            s["moves"] += 1
            if s["robot_pos"] == s["goal"]:
                s["status"] = "done"
                s["log"].append(
                    f"[Buoc {s['step_count']}] Robot da den ke hang dich sau "
                    f"{s['moves']} buoc di chuyen ({s['replans']} lan tinh duong)."
                )

    return jsonify(sim_to_json(s))


@app.route("/api/compare", methods=["POST"])
def compare():
    data = request.get_json(force=True)
    sim_id = data.get("sim_id")
    s = SIMS.get(sim_id)
    if not s:
        return jsonify({"error": "sim not found"}), 404

    planning_grid = build_planning_grid(s["static_grid"], s["dynamic_positions"])
    results = {}
    for name, fn in ALGORITHMS.items():
        path, expanded, ms = fn(planning_grid, s["start"], s["goal"])
        results[name] = {
            "path": path,
            "path_length": (len(path) - 1) if path else None,
            "nodes_expanded": expanded,
            "time_ms": round(ms, 4),
            "found": bool(path),
        }

    return jsonify(
        {
            "rows": s["rows"],
            "cols": s["cols"],
            "static_grid": s["static_grid"],
            "dynamic_positions": s["dynamic_positions"],
            "start": s["start"],
            "goal": s["goal"],
            "results": results,
        }
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
